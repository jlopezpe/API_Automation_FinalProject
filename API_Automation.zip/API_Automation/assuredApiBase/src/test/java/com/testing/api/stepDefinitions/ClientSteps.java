package com.testing.api.stepDefinitions;

import com.testing.api.models.Client;
import com.testing.api.requests.ClientRequest;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;

import java.util.List;
import java.util.Map;

public class ClientSteps {
    private static final Logger logger = LogManager.getLogger(ClientSteps.class);

    private final ClientRequest clientRequest = new ClientRequest();

    private static Map<String,String> clientDataList;

    private Response response;
    private Client clientResponse;
    private Client  client;

    @Given("there are registered clients in the system")
    public void thereAreRegisteredClientsInTheSystem() {
        response= clientRequest.getClients();
        // is the response 200?
        Assert.assertEquals(200,response.statusCode());
        List<Client> clients= clientRequest.getClientsEntity(response);
        //in case the list is empty, need to create a new one
        if(clients.size()==0){
            response=clientRequest.createDefaultClient();
            //verify if the new client is created successful
            Assert.assertEquals(201,response.statusCode());
        }

        logger.info("there are registered clients in the system");
    }

    @Given("I have a client with the following details:")
    public void iHaveAClientWithTheFollowingDetails(DataTable clientData) {

        clientDataList=clientData.asMaps().get(0);

        client=Client.builder().name(clientDataList.get("Name"))
                        .lastName(clientDataList.get("LastName"))
                        .country(clientDataList.get("Country"))
                .city(clientDataList.get("City"))
                        .email(clientDataList.get("Email"))
                        .phone(clientDataList.get("Phone"))
                        .build();
        logger.info("I have a client with the following details:" + clientData);
    }

    @When("I retrieve the details of the client with ID {string}")
    public void sendGETRequest(String clientId) {
        logger.info("I retrieve the details of the client with ID " + clientId);
        response=clientRequest.getClient(clientId);
        Assert.assertEquals(200,response.getStatusCode());
    }

    @When("I send a GET request to view all the clients")
    public void iSendAGETRequestToViewAllTheClient() {
        logger.info("I send a GET request to view all the clients");
        response=clientRequest.getClients();
    }

    @When("I send a POST request to create a client")
    public void iSendAPOSTRequestToCreateAClient() {

        response=clientRequest.createClient(client);
        logger.info("I send a POST request to create a client");
    }

    @When("I send a DELETE request to delete the client with ID {string}")
    public void iSendADELETERequestToDeleteTheClientWithID(String clientId) {
        logger.info("I send a DELETE request to delete the client with ID " + clientId);
        response=clientRequest.deleteClient(clientId);
        Assert.assertEquals(200,response.getStatusCode());
    }

    @When("I send a PUT request to update the client with ID {string}")
        public void iSendAPUTRequestToUpdateTheClientWithID(String clientId, String requestBody) {
        logger.info("I send a PUT request to update the client with ID " + requestBody + clientId);
        Client updatedClient = clientRequest.getClientEntity(requestBody);
        response = clientRequest.updateClient(updatedClient, clientId);
        Assert.assertEquals(200, response.getStatusCode());
    }

    @Then("the response should have a status code of {int}")
    public void theResponseShouldHaveAStatusCodeOf(int statusCode) {
        logger.info("the response should have a status code of " + statusCode);
        Assert.assertEquals(statusCode,response.statusCode());
    }

    @Then("the response should have the following details:")
    public void theResponseShouldHaveTheFollowingDetails(DataTable expectedData) {
        logger.info("the response should have the following details:" + expectedData);
        Map<String, String> detailsExpected = expectedData.asMaps().get(0);
        clientResponse = clientRequest.getClientEntity(response);
        Assert.assertEquals(detailsExpected.get("Name"), clientResponse.getName());
        Assert.assertEquals(detailsExpected.get("LastName"), clientResponse.getLastName());
        Assert.assertEquals(detailsExpected.get("Country"), clientResponse.getCountry());
        Assert.assertEquals(detailsExpected.get("City"), clientResponse.getCity());
        Assert.assertEquals(detailsExpected.get("Email"), clientResponse.getEmail());
        Assert.assertEquals(detailsExpected.get("Phone"), clientResponse.getPhone());

    }

    @Then("the response should include the details of the created client")
    public void theResponseShouldIncludeTheDetailsOfTheCreatedClient() {

        clientResponse=clientRequest.getClientEntity(response);
        Assert.assertEquals(clientResponse.getName(),client.getName());
        Assert.assertEquals(clientResponse.getLastName(),client.getLastName());
        Assert.assertEquals(clientResponse.getCity(),client.getCity());
        Assert.assertEquals(clientResponse.getCountry(),client.getCountry());
        Assert.assertEquals(clientResponse.getEmail(),client.getEmail());
        Assert.assertEquals(clientResponse.getPhone(),client.getPhone());
        //Assert.assertEquals(clientResponse.getId(),client.getId());
        logger.info("the response should include the details of the created client");
    }

    @Then("validates the response with client JSON schema")
    public void userValidatesResponseWithClientJSONSchema() {

        Assert.assertTrue(clientRequest.validateSchema(response,"schemas/clientSchema.json"));
        logger.info("validates the response with client JSON schema");
    }

    @Then("validates the response with client list JSON schema")
    public void userValidatesResponseWithClientListJSONSchema() {
        Assert.assertTrue(clientRequest.validateSchema(response,"schemas/clientListSchema.json"));
        logger.info("validates the response with client list JSON schema");
    }
}

package com.testing.api.stepDefinitions;

import com.testing.api.models.Client;
import com.testing.api.models.Resource;
import com.testing.api.requests.ResourceRequest;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;

import java.util.List;
import java.util.Map;

public class ResourceSteps{
    private static final Logger logger = LogManager.getLogger(ClientSteps.class);
    private static Response response;

    private Resource resource;
    private static final ResourceRequest resourceRequest= new ResourceRequest();

    private static Map<String,String> listResourceData;

    private Resource finalResource;

    @Given("there are registered resources in the system")
    public void thereAreRegisteredResourcesInTheSystem(){

        response=resourceRequest.getResources();
        Assert.assertEquals(200,response.statusCode());
        logger.info("resources in the system");
        List<Resource> listResources= resourceRequest.getResourcesEntity(response);
        if(listResources.size()==0){
            response=resourceRequest.createDefaultResource();
            Assert.assertEquals(201,response.statusCode());
            logger.info("new resource created");

        }
    }

    @When("I send a GET request to view all the resources")
    public void iSendAGetRequestToViewAllTheResources(){

        response=resourceRequest.getResources();
        //response.getStatusCode();
        logger.info("getting info of all the resources");
    }

    @Then("the response should have a status code of {int}")
    public void theResponseShouldHaveAStatusCodeOf(int statusCode) {
        logger.info("the response should have a status code of " + statusCode);
        Assert.assertEquals(statusCode,response.statusCode());
    }

    @And("validates the response with the resource list Json Schema")
    public void validatesTheResponseWithTheResourceListJsonSchema(){
        Assert.assertTrue(resourceRequest.validateSchema(response,"schemas/resourceListSchema.json"));
    }

    @And("I retrieve the details of the latest resource")
    public void iRetrieveDetailsOfTheLastResource(){
        List<Resource> resources= resourceRequest.getResourcesEntity(response);
        finalResource= resources.get(resources.size()-1);
    }

    @When("I send a PUT request to update the last resource")
    public void iSendAPUTRequestToUpdateTheLastResource(String requestBody){

        logger.info(requestBody);
        response=resourceRequest.updateResource(resourceRequest.getResourceEntity(requestBody),finalResource.getId());

    }

    @And("the response should have the following details")
    public void theResponseHaveTheFollowingDetails(DataTable tableResourceData){

        listResourceData=tableResourceData.asMaps().get(0);
        resource= Resource.builder().name(listResourceData.get("name"))
                .trademark(listResourceData.get("trademark"))
                .stock(Integer.parseInt(listResourceData.get("stock")))
                .price(Double.valueOf(listResourceData.get("price")))
                .description(listResourceData.get("description"))
                .tags(listResourceData.get("tags"))
                .active(Boolean.valueOf(listResourceData.get("active")))
                .build();

        Resource entityResource= resourceRequest.getResourceEntity(response);
        Assert.assertEquals(entityResource.getName(),resource.getName());
        Assert.assertEquals(entityResource.getTrademark(),resource.getTrademark());
        Assert.assertEquals(entityResource.getStock(),resource.getStock());
        Assert.assertEquals(entityResource.getPrice(),resource.getPrice());
        Assert.assertEquals(entityResource.getDescription(),resource.getDescription());
        Assert.assertEquals(entityResource.getTags(),resource.getTags());
        Assert.assertEquals(entityResource.getActive(),resource.getActive());

        logger.info("Resource details matches");
    }

    @And("validates the response with the resource Json Schema")
    public void validateTheResponseWithResourceJsonSchema(){
        Assert.assertTrue(resourceRequest.validateSchema(response,"schemas/resourceSchema.json"));
    }


}
